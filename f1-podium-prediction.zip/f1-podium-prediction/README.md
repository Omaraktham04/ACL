# F1 Podium Prediction Companion: Milestone 1

Predict whether a driver will finish on the **podium** (`positionOrder ≤ 3`) using only information available **after qualifying and before the race starts**. The data is the Kaggle / Ergast *Formula 1 World Championship (1950–2024)* dataset.

## Results at a glance
| | |
|---|---|
| Modelling table | 8,970 unique driver-races (2003–2024), 28 leakage-safe features |
| Split | temporal: train 2003–2016 · validation 2017–2020 · **test 2021–2024** |
| Selected model | Random forest (chosen on validation PR-AUC) |
| Test PR-AUC / ROC-AUC / F1 | **0.720 / 0.940 / 0.677** (grid-only baseline 0.646 / 0.911 / 0.661) |
| Q1 | front row → podium 68% (2003–13) vs 76% (2014–24); circuit ranking not stable (ρ = 0.30) |
| Q2 | no home advantage after controlling for grid (OR 0.92, 95% CI 0.78–1.08) |
| Q3 | mechanical DNFs 9.6% → 6.0% of starts; worst: Caterham/Lotus/Toro Rosso, then Alfa Romeo/Alpine/AlphaTauri |

## Repository layout
```
F1_Podium_Prediction_MS1.ipynb   <- the run-all notebook (executed, with all outputs)
f1podium/                        <- reusable package (written by the notebook)
    cleaning.py  grain.py  entries.py  features.py  preprocessing.py
    models.py    pipeline.py  inference.py
artifacts/                       <- fitted model + feature spec + modelling table + cleaned tables
figures/                         <- every figure used in the report
outputs/                         <- result tables (model comparison, ablation, experiments) + results.json
report/F1_Podium_MS1_Report.pdf  <- analytical report
report/Evaluation_Prep_QA.pdf    <- likely evaluation questions with short answers
requirements.txt
```

## How to run
**Kaggle:** create a notebook, add the dataset `rohanrao/formula-1-world-championship-1950-2020` as input, upload `F1_Podium_Prediction_MS1.ipynb`, then click **Run All**. The data folder is detected automatically.

**Locally:**
```bash
pip install -r requirements.txt
# put the 14 CSV files in ./data/
jupyter nbconvert --to notebook --execute F1_Podium_Prediction_MS1.ipynb --output F1_Podium_Prediction_MS1.ipynb
```
Runtime is about 3 minutes on CPU. All randomness is seeded (`SEED = 42`).

## Re-using the work in later milestones
```python
from f1podium.pipeline import build_modelling_table      # raw CSVs -> leakage-safe table
table = build_modelling_table('data', start=2003)

from f1podium.inference import predict_podium            # uses artifacts/model.joblib
predict_podium({'grid_pos': 2, 'quali_pos': 2, 'quali_gap_pct': 0.1, 'con_pts_share': 0.9})
# -> {'p_podium': ..., 'podium': True/False, 'imputed_by_model': [...], ...}
```
* `artifacts/feature_spec.json` holds the feature list, groups, decision threshold, training medians and metrics.
* All models share the scikit-learn `fit` / `predict_proba` interface, so a new model drops in without other changes.
* Post-race fields (`points`, `positionOrder`, `statusId`, …) are rejected at prediction time.
