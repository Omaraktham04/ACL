"""Joined driver-race analysis table, status taxonomy and home-race flag."""
import numpy as np
import pandas as pd

FINISHED_PATTERN = r'^(Finished|\+\d+ Laps?|Lapped)$'
# Mechanical retirement = a component of the car failed (no crash, no driver error, no regulation decision)
MECHANICAL = {'Engine', 'Gearbox', 'Transmission', 'Clutch', 'Hydraulics', 'Electrical', 'Radiator', 'Suspension',
              'Brakes', 'Differential', 'Overheating', 'Mechanical', 'Driveshaft', 'Fuel pressure', 'Water pressure',
              'Throttle', 'Steering', 'Technical', 'Electronics', 'Exhaust', 'Oil leak', 'Water leak', 'Fuel pump',
              'Oil pressure', 'Engine fire', 'Engine misfire', 'Pneumatics', 'Fuel system', 'Oil line', 'Power loss',
              'Drivetrain', 'Ignition', 'Battery', 'Halfshaft', 'Crankshaft', 'Alternator', 'Oil pump', 'Fuel leak',
              'Injection', 'Distributor', 'Turbo', 'CV joint', 'Water pump', 'Spark plugs', 'Fuel pipe', 'Oil pipe',
              'Axle', 'Water pipe', 'Magneto', 'Supercharger', 'Power Unit', 'ERS', 'Brake duct', 'Cooling system',
              'Wheel bearing', 'Wheel rim', 'Wheel', 'Heat shield fire', 'Launch control', 'Vibrations', 'Vibration',
              'Handling', 'Seat', 'Driver Seat', 'Safety belt', 'Undertray', 'Chassis', 'Fuel'}
NOT_STARTED = {'Did not qualify', 'Did not prequalify', 'Did not start', 'Withdrew', '107% Rule', 'Excluded'}

# nationality adjective -> circuit country name(s) (dual nationalities count both)
NAT2COUNTRY = {'British': ['UK'], 'German': ['Germany'], 'East German': ['Germany'], 'Spanish': ['Spain'],
               'Finnish': ['Finland'], 'Japanese': ['Japan'], 'French': ['France'], 'Polish': ['Poland'],
               'Brazilian': ['Brazil'], 'Italian': ['Italy'], 'Australian': ['Australia'], 'Austrian': ['Austria'],
               'American': ['USA'], 'Dutch': ['Netherlands'], 'Colombian': ['Colombia'], 'Portuguese': ['Portugal'],
               'Canadian': ['Canada'], 'Indian': ['India'], 'Hungarian': ['Hungary'], 'Irish': ['Ireland'],
               'Danish': ['Denmark'], 'Argentine': ['Argentina'], 'Czech': ['Czech Republic'], 'Malaysian': ['Malaysia'],
               'Swiss': ['Switzerland'], 'Belgian': ['Belgium'], 'Monegasque': ['Monaco'], 'Swedish': ['Sweden'],
               'Venezuelan': ['Venezuela'], 'New Zealander': ['New Zealand'], 'Chilean': ['Chile'], 'Mexican': ['Mexico'],
               'South African': ['South Africa'], 'Liechtensteiner': ['Liechtenstein'], 'Rhodesian': ['Rhodesia'],
               'American-Italian': ['USA', 'Italy'], 'Argentine-Italian': ['Argentina', 'Italy'], 'Uruguayan': ['Uruguay'],
               'Thai': ['Thailand'], 'Russian': ['Russia'], 'Indonesian': ['Indonesia'], 'Chinese': ['China'],
               'Emirati': ['United Arab Emirates'], 'Saudi': ['Saudi Arabia'], 'Moroccan': ['Morocco'], 'Turkish': ['Turkey']}


def is_home(nat, country):
    """True if the circuit is in (one of) the driver's nationality countries."""
    return isinstance(nat, str) and country in NAT2COUNTRY.get(nat, [])


def status_table(status):
    s = status.copy()
    s['is_finished'] = s.status.str.match(FINISHED_PATTERN)
    s['is_mechanical'] = s.status.isin(MECHANICAL)
    s['is_started'] = ~s.status.isin(NOT_STARTED)
    return s


def build_entries(clean):
    """results_u (unique grain) + races + circuits + drivers + constructors + status + qualifying. One row per driver-race."""
    status = status_table(clean['status'])
    races_x = clean['races'].merge(clean['circuits'][['circuitId', 'circuitRef', 'name', 'country']]
                                   .rename(columns={'name': 'circuit_name', 'country': 'circuit_country'}), on='circuitId')
    e = (clean['results_u']
         .merge(races_x[['raceId', 'year', 'round', 'date', 'name', 'circuitId', 'circuitRef', 'circuit_name', 'circuit_country']], on='raceId')
         .merge(clean['drivers'][['driverId', 'driverRef', 'forename', 'surname', 'dob', 'nationality']], on='driverId')
         .merge(clean['constructors'][['constructorId', 'name']].rename(columns={'name': 'constructor'}), on='constructorId')
         .merge(status, on='statusId')
         .merge(clean['qualifying'][['raceId', 'driverId', 'position', 'q1_s', 'q2_s', 'q3_s']]
                .rename(columns={'position': 'quali_pos'}), on=['raceId', 'driverId'], how='left'))
    e['podium'] = (e.positionOrder <= 3).astype(int)
    e['home_race'] = [is_home(n, c) for n, c in zip(e.nationality, e.circuit_country)]
    e = e.sort_values(['date', 'raceId', 'positionOrder']).reset_index(drop=True)
    assert not e.duplicated(['raceId', 'driverId']).any() and len(e) == len(clean['results_u'])
    return e
