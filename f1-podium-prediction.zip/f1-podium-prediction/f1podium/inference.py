"""Load the saved model + spec and predict P(podium) for one pre-race record (dict) or a DataFrame."""
import json
import os
import numpy as np
import pandas as pd

LEAKAGE_FIELDS = {'positionOrder', 'position', 'positionText', 'points', 'laps', 'time', 'milliseconds', 'statusId',
                  'status', 'fastestLap', 'fastestLapTime', 'fastestLapSpeed', 'rank', 'podium', 'pit_stops', 'lap_times'}


class PodiumPredictor:
    def __init__(self, model, spec):
        self.model, self.spec = model, spec
        self.features, self.threshold = spec['features'], float(spec['threshold'])

    @classmethod
    def load(cls, artifact_dir='artifacts'):
        import joblib
        model = joblib.load(os.path.join(artifact_dir, 'model.joblib'))
        spec = json.load(open(os.path.join(artifact_dir, 'feature_spec.json')))
        return cls(model, spec)

    def _frame(self, record):
        leak = LEAKAGE_FIELDS & set(record)
        if leak:
            raise ValueError(f'post-race (leakage) fields are not allowed at prediction time: {sorted(leak)}')
        unknown = set(record) - set(self.features) - {'raceId', 'driverId', 'driver', 'race'}
        rec = {f: record.get(f, np.nan) for f in self.features}
        rec = {k: (np.nan if v is None else v) for k, v in rec.items()}
        derived = []
        if pd.isna(rec.get('grid_pos')) and not pd.isna(rec.get('quali_pos')):
            rec['grid_pos'] = rec['quali_pos']; derived.append('grid_pos<-quali_pos')
            if pd.isna(rec.get('grid_penalty')):
                rec['grid_penalty'] = 0.0; derived.append('grid_penalty<-0')
        if pd.isna(rec.get('pitlane_start')) and not pd.isna(rec.get('grid_pos')):
            rec['pitlane_start'] = 0; derived.append('pitlane_start<-0')
        X = pd.DataFrame([rec], columns=self.features).astype(float)
        imputed = [f for f in self.features if pd.isna(X.at[0, f])]
        return X, imputed, derived, sorted(unknown)

    def predict(self, record):
        X, imputed, derived, unknown = self._frame(record)
        p = float(self.model.predict_proba(X)[0, 1])
        return {'p_podium': round(p, 4), 'podium': bool(p >= self.threshold), 'threshold': round(self.threshold, 4),
                'n_inputs_given': len(self.features) - len(imputed) - len(derived),
                'imputed_by_model': imputed, 'derived_by_rule': derived, 'ignored_unknown_keys': unknown}

    def predict_frame(self, df):
        return self.model.predict_proba(df[self.features].astype(float))[:, 1]


_DEFAULT = None


def predict_podium(record, predictor=None, artifact_dir='artifacts'):
    """Convenience wrapper: predict_podium({'grid_pos': 2, 'quali_pos': 2, ...})"""
    global _DEFAULT
    if predictor is None:
        if _DEFAULT is None:
            _DEFAULT = PodiumPredictor.load(artifact_dir)
        predictor = _DEFAULT
    return predictor.predict(record)
