"""Evaluation helpers and a shallow feed-forward neural network with a scikit-learn interface."""
import copy
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import (roc_auc_score, average_precision_score, f1_score, precision_score, recall_score,
                             precision_recall_curve, log_loss)
from f1podium.preprocessing import make_prep

METRICS = ['ROC-AUC', 'PR-AUC', 'F1', 'Precision', 'Recall']


def best_f1_threshold(y, p):
    """Threshold maximising F1 (to be computed on VALIDATION data only)."""
    prec, rec, thr = precision_recall_curve(y, p)
    f1 = 2 * prec * rec / np.clip(prec + rec, 1e-12, None)
    i = int(np.nanargmax(f1[:-1]))
    return float(thr[i])


def evaluate(y, p, thr):
    yhat = (p >= thr).astype(int)
    return {'ROC-AUC': roc_auc_score(y, p), 'PR-AUC': average_precision_score(y, p),
            'F1': f1_score(y, yhat, zero_division=0), 'Precision': precision_score(y, yhat, zero_division=0),
            'Recall': recall_score(y, yhat, zero_division=0)}


def top3_hit_rate(race_ids, y, p):
    """Per race: share of the 3 highest-probability drivers that actually finished on the podium."""
    d = pd.DataFrame({'race': np.asarray(race_ids), 'y': np.asarray(y), 'p': np.asarray(p)})
    d['rk'] = d.groupby('race').p.rank(ascending=False, method='first')
    return float(d[d.rk <= 3].y.mean())


class ShallowNN(BaseEstimator, ClassifierMixin):
    """Feed-forward network with 1-2 hidden ReLU layers (scikit-learn MLP, Adam, L2 penalty `alpha`).
    Preprocessing (winsorise -> median impute + indicators -> standardise) is part of the estimator.
    Trained epoch by epoch with early stopping on the supplied VALIDATION set (best epoch restored)."""

    def __init__(self, hidden=(64, 32), alpha=1e-4, lr=1e-3, batch_size=128, max_epochs=200, patience=20, seed=42):
        self.hidden, self.alpha, self.lr, self.batch_size = hidden, alpha, lr, batch_size
        self.max_epochs, self.patience, self.seed = max_epochs, patience, seed

    def fit(self, X, y, X_val=None, y_val=None):
        y = np.asarray(y)
        self.prep_ = make_prep(scale=True).fit(X)
        Xt = self.prep_.transform(X)
        Xv = self.prep_.transform(X_val) if X_val is not None else None
        net = MLPClassifier(hidden_layer_sizes=self.hidden, activation='relu', solver='adam', alpha=self.alpha,
                            learning_rate_init=self.lr, batch_size=self.batch_size, random_state=self.seed)
        rng = np.random.default_rng(self.seed)
        self.history_, best, wait = [], -np.inf, 0
        self.classes_ = np.array([0, 1])
        for epoch in range(1, self.max_epochs + 1):
            idx = rng.permutation(len(Xt))
            net.partial_fit(Xt[idx], y[idx], classes=self.classes_)
            rec = {'epoch': epoch, 'train_loss': log_loss(y, net.predict_proba(Xt)[:, 1], labels=[0, 1])}
            if Xv is not None:
                pv = net.predict_proba(Xv)[:, 1]
                rec.update(val_loss=log_loss(y_val, pv, labels=[0, 1]), val_pr_auc=average_precision_score(y_val, pv))
                score = rec['val_pr_auc']
            else:
                score = -rec['train_loss']
            self.history_.append(rec)
            if score > best + 1e-4:
                best, wait, self.net_, self.best_epoch_ = score, 0, copy.deepcopy(net), epoch
            else:
                wait += 1
                if wait >= self.patience:
                    break
        self.history_ = pd.DataFrame(self.history_)
        return self

    def predict_proba(self, X):
        return self.net_.predict_proba(self.prep_.transform(X))

    def predict(self, X):
        return (self.predict_proba(X)[:, 1] >= 0.5).astype(int)
