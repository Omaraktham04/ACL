"""Leakage-safe feature builder. Every history feature is shifted by one race; standings come from the previous round."""
import numpy as np
import pandas as pd


def build_features(ent, ds, cs, races):
    """ent: output of entries.build_entries; ds/cs: driver/constructor standings; races: clean races table.
    Returns one row per (raceId, driverId) for all seasons with all FEATURES (pre-race information only)."""
    df = ent.copy().sort_values(['date', 'raceId']).reset_index(drop=True)
    df['positionOrder_f'] = df.positionOrder.astype(float)
    # ---- context / grid -------------------------------------------------------------
    df['field_size'] = df.groupby('raceId').driverId.transform('size')
    df['pitlane_start'] = (df.grid.fillna(0) <= 0).astype(int)
    df['grid_pos'] = df.grid.where(df.grid > 0, df.field_size).astype(float)
    df['home_race'] = df.home_race.astype(int)
    df['driver_age'] = (df.date - df.dob).dt.days / 365.25
    # ---- qualifying -----------------------------------------------------------------
    df['quali_pos'] = df.quali_pos.astype(float)
    best = df[['q1_s', 'q2_s', 'q3_s']].min(axis=1)
    df['quali_gap_pct'] = (best / best.groupby(df.raceId).transform('min') - 1) * 100
    df['grid_penalty'] = df.grid_pos - df.quali_pos
    grp = df.groupby(['raceId', 'constructorId']).quali_pos
    mate_mean = (grp.transform('sum') - df.quali_pos) / (grp.transform('count') - 1)
    df['teammate_quali_diff'] = df.quali_pos - mate_mean.replace([np.inf, -np.inf], np.nan)
    # ---- standings BEFORE the race (= after the previous round) -------------------
    rr = races[['raceId', 'year', 'round']].sort_values(['year', 'round']).copy()
    rr['prev_raceId'] = rr.groupby('year').raceId.shift(1)
    df = df.merge(rr[['raceId', 'prev_raceId']], on='raceId', how='left')
    d_ = ds[['raceId', 'driverId', 'points', 'position', 'wins']].copy()
    d_['leader'] = d_.groupby('raceId').points.transform('max')
    d_ = d_.rename(columns={'raceId': 'prev_raceId', 'points': 'drv_pts', 'position': 'drv_champ_pos', 'wins': 'drv_season_wins', 'leader': 'drv_leader'})
    c_ = cs[['raceId', 'constructorId', 'points', 'position']].copy()
    c_['leader'] = c_.groupby('raceId').points.transform('max')
    c_ = c_.rename(columns={'raceId': 'prev_raceId', 'points': 'con_pts', 'position': 'con_champ_pos', 'leader': 'con_leader'})
    df = df.merge(d_, on=['prev_raceId', 'driverId'], how='left').merge(c_, on=['prev_raceId', 'constructorId'], how='left')
    df['first_round'] = df.prev_raceId.isna().astype(int)
    df['drv_pts_share'] = (df.drv_pts / df.drv_leader.replace(0, np.nan)).fillna(0)
    df['con_pts_share'] = (df.con_pts / df.con_leader.replace(0, np.nan)).fillna(0)
    df['drv_season_wins'] = df.drv_season_wins.fillna(0)
    df['drv_champ_pos'] = df.drv_champ_pos.astype(float)
    df['con_champ_pos'] = df.con_champ_pos.astype(float)
    # final standings of the previous season
    last = rr.groupby('year').raceId.last().reset_index().rename(columns={'raceId': 'last_raceId'})
    fd = ds.merge(last, left_on='raceId', right_on='last_raceId')[['year', 'driverId', 'position']]
    fd = fd.assign(year=fd.year + 1).rename(columns={'position': 'prev_season_drv_pos'})
    fc = cs.merge(last, left_on='raceId', right_on='last_raceId')[['year', 'constructorId', 'position']]
    fc = fc.assign(year=fc.year + 1).rename(columns={'position': 'prev_season_con_pos'})
    df = df.merge(fd, on=['year', 'driverId'], how='left').merge(fc, on=['year', 'constructorId'], how='left')
    df[['prev_season_drv_pos', 'prev_season_con_pos']] = df[['prev_season_drv_pos', 'prev_season_con_pos']].astype(float)
    df = df.sort_values(['date', 'raceId']).reset_index(drop=True)
    # ---- driver form & experience (past races only) --------------------------------
    df['dnf'] = (~df.is_finished).astype(int)
    df['mech_dnf'] = df.is_mechanical.astype(int)
    gd = df.groupby('driverId')
    past_mean = lambda col, w: gd[col].transform(lambda s: s.shift(1).rolling(w, min_periods=1).mean())
    df['drv_podium_rate_5'] = past_mean('podium', 5)
    df['drv_avg_finish_5'] = past_mean('positionOrder_f', 5)
    df['drv_dnf_rate_5'] = past_mean('dnf', 5)
    df['drv_avg_grid_5'] = past_mean('grid_pos', 5)
    df['drv_prior_starts'] = gd.cumcount()
    df['drv_career_podium_rate'] = gd['podium'].transform(lambda s: s.shift(1).expanding().mean())
    gdc = df.groupby(['driverId', 'circuitId'])
    df['drv_circuit_starts'] = gdc.cumcount()
    df['drv_circuit_podium_rate'] = gdc['podium'].transform(lambda s: s.shift(1).expanding().mean())
    # ---- constructor form (aggregate per race first, so the team-mate's CURRENT result never leaks) ----
    cr = (df.groupby(['raceId', 'constructorId'], as_index=False)
            .agg(date=('date', 'first'), c_pod=('podium', 'sum'), c_n=('podium', 'size'),
                 c_mech=('mech_dnf', 'sum'), c_best=('positionOrder_f', 'min'))
            .sort_values(['date', 'raceId']))
    gc = cr.groupby('constructorId')
    past_sum = lambda col, w: gc[col].transform(lambda s: s.shift(1).rolling(w, min_periods=1).sum())
    cr['con_podium_rate_5'] = past_sum('c_pod', 5) / past_sum('c_n', 5)
    cr['con_mech_dnf_rate_10'] = past_sum('c_mech', 10) / past_sum('c_n', 10)
    cr['con_best_finish_5'] = gc['c_best'].transform(lambda s: s.shift(1).rolling(5, min_periods=1).mean())
    df = df.merge(cr[['raceId', 'constructorId', 'con_podium_rate_5', 'con_mech_dnf_rate_10', 'con_best_finish_5']],
                  on=['raceId', 'constructorId'], how='left')
    return df.sort_values(['date', 'raceId', 'grid_pos']).reset_index(drop=True)

FEATURE_GROUPS = {
    'grid': ['grid_pos', 'pitlane_start'],
    'qualifying': ['quali_pos', 'quali_gap_pct', 'grid_penalty', 'teammate_quali_diff'],
    'standings': ['drv_pts_share', 'drv_champ_pos', 'drv_season_wins', 'con_pts_share', 'con_champ_pos',
                  'prev_season_drv_pos', 'prev_season_con_pos', 'first_round'],
    'driver_form': ['drv_podium_rate_5', 'drv_avg_finish_5', 'drv_dnf_rate_5', 'drv_avg_grid_5'],
    'constructor_form': ['con_podium_rate_5', 'con_best_finish_5', 'con_mech_dnf_rate_10'],
    'experience': ['drv_prior_starts', 'drv_career_podium_rate', 'drv_circuit_starts', 'drv_circuit_podium_rate', 'driver_age'],
    'context': ['home_race', 'field_size'],
}
FEATURES = [f for g in FEATURE_GROUPS.values() for f in g]
META = ['raceId', 'driverId', 'constructorId', 'year', 'round', 'date', 'name', 'driverRef', 'constructor', 'grid', 'positionOrder']
TARGET = 'podium'
