"""One call from the raw CSV folder to the leakage-safe modelling table."""
from f1podium import cleaning, grain, entries, features


def load_clean(data_dir, last_season=2024):
    raw = cleaning.load_raw(data_dir)
    clean = {t: cleaning.clean_table(raw[t], cleaning.SCHEMA[t]) for t in cleaning.TABLES}
    cleaning.apply_scope(clean, last_season)
    cleaning.fix_implausible_quali(clean)
    cleaning.canonicalise(clean)
    cleaning.drop_duplicate_laps(clean)
    clean['results_u'] = grain.dedupe_results(clean['results'])
    return clean


def build_all(data_dir, last_season=2024):
    """Returns (clean tables, joined entries, feature table for ALL seasons)."""
    clean = load_clean(data_dir, last_season)
    ent = entries.build_entries(clean)
    feat = features.build_features(ent, clean['driver_standings'], clean['constructor_standings'], clean['races'])
    return clean, ent, feat


def build_modelling_table(data_dir, start=2003, last_season=2024):
    _, _, feat = build_all(data_dir, last_season)
    return feat[feat.year.between(start, last_season)].reset_index(drop=True)
