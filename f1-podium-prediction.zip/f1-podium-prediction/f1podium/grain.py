"""Grain fix: exactly one row per (raceId, driverId)."""
import numpy as np
import pandas as pd


def dedupe_results(res):
    """Shared drives -> one row. Pre-race attributes from the car the driver STARTED (lowest valid grid,
    then lowest resultId); outcome = best positionOrder over the driver's rows; points summed; n_entries kept."""
    r = res.copy()
    r['_g'] = r.grid.where(r.grid > 0, np.inf)
    r = r.sort_values(['raceId', 'driverId', '_g', 'resultId'])
    agg = r.groupby(['raceId', 'driverId']).agg(positionOrder_best=('positionOrder', 'min'),
                                                points_total=('points', 'sum'),
                                                n_entries=('resultId', 'size')).reset_index()
    first = r.drop_duplicates(['raceId', 'driverId'], keep='first').drop(columns='_g')
    out = first.merge(agg, on=['raceId', 'driverId'])
    out['positionOrder'] = out['positionOrder_best'].astype('Int64')
    out['points'] = out['points_total']
    return out.drop(columns=['positionOrder_best', 'points_total'])
