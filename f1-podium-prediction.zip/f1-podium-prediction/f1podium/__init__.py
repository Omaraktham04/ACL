"""f1podium: reusable data-engineering + modelling code for the F1 podium-prediction project.

Modules (written by the Milestone-1 notebook):
    cleaning       sentinel handling, semantic typing, scope filter, categorical canonicalisation
    grain          duplicate handling -> one row per (raceId, driverId)
    entries        joined driver-race analysis table + status taxonomy + home-race flag
    features       leakage-safe feature builder and feature groups
    preprocessing  train-fitted winsoriser / imputer / scaler pipelines
    models         shallow neural network wrapper + evaluation metrics
    pipeline       one call from raw CSV folder to the modelling table
    inference      load saved artifacts and predict a podium probability for one record
"""
__version__ = '1.0.0'
