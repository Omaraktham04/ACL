"""Preprocessing pipelines (always fitted on the training split only)."""
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.base import BaseEstimator, TransformerMixin

class Winsorizer(BaseEstimator, TransformerMixin):
    """Clip selected columns to [q_low, q_high] quantiles learned on the training data."""
    def __init__(self, columns=None, q=(0.01, 0.99)):
        self.columns, self.q = columns, q
    def fit(self, X, y=None):
        X = pd.DataFrame(X)
        self.bounds_ = {c: X[c].quantile(list(self.q)).values for c in (self.columns or []) if c in X.columns}
        return self
    def transform(self, X):
        X = pd.DataFrame(X).copy()
        for c, (lo, hi) in self.bounds_.items():
            X[c] = X[c].clip(lo, hi)
        return X

WINSOR_COLS = ['quali_gap_pct', 'teammate_quali_diff', 'grid_penalty']

def make_prep(scale=True):
    steps = [('winsor', Winsorizer(WINSOR_COLS)), ('impute', SimpleImputer(strategy='median', add_indicator=True))]
    if scale:
        steps.append(('scale', StandardScaler()))
    return Pipeline(steps)
