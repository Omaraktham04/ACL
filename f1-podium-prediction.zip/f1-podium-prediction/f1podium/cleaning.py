"""Cleaning: sentinel handling, semantic typing, season scope, categorical canonicalisation."""
import numpy as np
import pandas as pd

TABLES = ['circuits', 'constructors', 'constructor_results', 'constructor_standings', 'drivers',
          'driver_standings', 'races', 'results', 'qualifying', 'lap_times', 'pit_stops',
          'sprint_results', 'seasons', 'status']
RACE_CHILD_TABLES = ['results', 'qualifying', 'lap_times', 'pit_stops', 'sprint_results', 'driver_standings',
                     'constructor_standings', 'constructor_results']
COUNTRY_CANON = {'United States': 'USA', 'United Kingdom': 'UK', 'Great Britain': 'UK', 'UAE': 'United Arab Emirates'}
NAT_CANON = {'Argentinian': 'Argentine'}


def load_raw(data_dir):
    """Read every table as untyped text, exactly as written in the CSV (the \\N sentinel is kept)."""
    import os
    return {t: pd.read_csv(os.path.join(data_dir, f'{t}.csv'), dtype=str, keep_default_na=False, na_filter=False)
            for t in TABLES}


def parse_duration(series):
    """'1:27.452' -> 87.452 s ; '27.4' -> 27.4 s ; '1:02:03.5' -> 3723.5 s ; invalid/missing -> NaN"""
    def conv(x):
        if not isinstance(x, str) or not x.strip():
            return np.nan
        try:
            sec = 0.0
            for part in x.strip().split(':'):
                sec = sec * 60 + float(part)
            return sec
        except ValueError:
            return np.nan
    return series.map(conv).astype(float)

SCHEMA = {
    'circuits':  dict(int=['circuitId'], float=['lat', 'lng', 'alt']),
    'constructors': dict(int=['constructorId']),
    'constructor_results': dict(int=['constructorResultsId', 'raceId', 'constructorId'], float=['points']),
    'constructor_standings': dict(int=['constructorStandingsId', 'raceId', 'constructorId', 'position', 'wins'], float=['points']),
    'drivers': dict(int=['driverId'], float=['number'], date=['dob']),
    'driver_standings': dict(int=['driverStandingsId', 'raceId', 'driverId', 'position', 'wins'], float=['points']),
    'races': dict(int=['raceId', 'year', 'round', 'circuitId'], date=['date', 'fp1_date', 'fp2_date', 'fp3_date', 'quali_date', 'sprint_date']),
    'results': dict(int=['resultId', 'raceId', 'driverId', 'constructorId', 'positionOrder', 'laps', 'statusId'],
                    float=['number', 'grid', 'position', 'points', 'milliseconds', 'fastestLap', 'rank', 'fastestLapSpeed'],
                    duration=['fastestLapTime']),
    'qualifying': dict(int=['qualifyId', 'raceId', 'driverId', 'constructorId', 'position'], float=['number'],
                       duration=['q1', 'q2', 'q3']),
    'lap_times': dict(int=['raceId', 'driverId', 'lap', 'position'], float=['milliseconds'], duration=['time']),
    'pit_stops': dict(int=['raceId', 'driverId', 'stop', 'lap'], float=['milliseconds'], duration=['duration']),
    'sprint_results': dict(int=['resultId', 'raceId', 'driverId', 'constructorId', 'positionOrder', 'laps', 'statusId'],
                           float=['number', 'grid', 'position', 'points', 'milliseconds', 'fastestLap'],
                           duration=['fastestLapTime']),
    'seasons': dict(int=['year']),
    'status': dict(int=['statusId']),
}

def clean_table(df_raw, schema):
    """Return a typed copy of one raw table (the raw frame is never modified)."""
    df = df_raw.copy()
    for c in df.columns:
        df[c] = df[c].str.strip()
    df = df.replace({'\\N': np.nan, '': np.nan})
    for c in schema.get('int', []):
        df[c] = pd.to_numeric(df[c], errors='coerce').astype('Int64')
    for c in schema.get('float', []):
        df[c] = pd.to_numeric(df[c], errors='coerce').astype(float)
    for c in schema.get('date', []):
        df[c] = pd.to_datetime(df[c], errors='coerce')
    for c in schema.get('duration', []):
        df[c + '_s'] = parse_duration(df[c])
    return df


def apply_scope(clean, last_season):
    """Keep seasons <= last_season; child tables keep only races in scope. Returns {table: (before, after)}."""
    log = {}
    clean['races'] = clean['races'][clean['races'].year <= last_season].copy()
    clean['seasons'] = clean['seasons'][clean['seasons'].year <= last_season].copy()
    in_scope = set(clean['races'].raceId)
    for t in RACE_CHILD_TABLES:
        before = len(clean[t])
        clean[t] = clean[t][clean[t].raceId.isin(in_scope)].copy()
        log[t] = (before, len(clean[t]))
    return log


def fix_implausible_quali(clean, lo=40, hi=400):
    """Qualifying lap times outside [lo, hi] seconds are recording errors -> NaN."""
    for c in ['q1_s', 'q2_s', 'q3_s']:
        bad = (clean['qualifying'][c] < lo) | (clean['qualifying'][c] > hi)
        clean['qualifying'].loc[bad, c] = np.nan


def canonicalise(clean):
    """One spelling per country / nationality (needed for the home-race join)."""
    clean['circuits']['country'] = clean['circuits'].country.replace(COUNTRY_CANON)
    clean['drivers']['nationality'] = clean['drivers'].nationality.str.strip().replace(NAT_CANON)


def drop_duplicate_laps(clean):
    """lap_times: the same lap loaded twice (identical or 1 ms rounding) -> keep the first copy."""
    clean['lap_times'] = clean['lap_times'].drop_duplicates(['raceId', 'driverId', 'lap'], keep='first').copy()
